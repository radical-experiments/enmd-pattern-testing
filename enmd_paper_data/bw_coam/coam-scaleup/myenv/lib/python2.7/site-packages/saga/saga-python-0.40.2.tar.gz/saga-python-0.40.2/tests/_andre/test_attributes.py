
import saga
from   pprint import pprint as p

class Description (saga.Attributes) :

    def __init__(self, seed):

        import saga.attributes as sa

        saga.Attributes.__init__ (self)

        self._attributes_extensible    (False)
        self._attributes_allow_private (True)
        self._attributes_camelcasing   (True)

        # register properties with the attribute interface

        self._attributes_register  ('_config'                     , None, sa.STRING, sa.SCALAR, sa.WRITEABLE)
        self._attributes_register  (saga.job.EXECUTABLE           , None, sa.STRING, sa.SCALAR, sa.WRITEABLE)
        self._attributes_register  (saga.job.INTERACTIVE          , None, sa.BOOL,   sa.SCALAR, sa.WRITEABLE)
        self._attributes_register  (saga.job.CLEANUP              , None, sa.BOOL,   sa.SCALAR, sa.WRITEABLE)
        self._attributes_register  (saga.job.JOB_START_TIME       , None, sa.TIME,   sa.SCALAR, sa.WRITEABLE)
        self._attributes_register  (saga.job.ENVIRONMENT          , None, sa.STRING, sa.VECTOR, sa.WRITEABLE)
        self._attributes_register  (saga.job.SPMD_VARIATION       , None, sa.ENUM,   sa.SCALAR, sa.WRITEABLE)
        self._attributes_set_enums (saga.job.SPMD_VARIATION,      ['MPI', 'OpenMP', 'MPICH-G'])

        self._env_is_list = False

        self._attributes_set_getter (saga.job.ENVIRONMENT, self._get_env)
        self._attributes_set_setter (saga.job.ENVIRONMENT, self._set_env)

        self.from_dict(seed)


    # --------------------------------------------------------------------------
    #
    def _set_env (self, val) :
        if  isinstance (val, list) :
            self._env_is_list = True


    # --------------------------------------------------------------------------
    #
    def _get_env (self) :
        env = self.get_attribute (saga.job.ENVIRONMENT)
        if  self._env_is_list :
            self._env_is_list = False
            return ["%s=%s" % (key, val) for (key, val) in env.items ()]
        return env


seed_1 = {'executable' : '/bin/date',
          'invalid'    : True}
seed_2 = {'executable' : '/bin/date'}

try :
    d = Description(seed_1)
except saga.exceptions.IncorrectState:
    pass

d = Description(seed_2)

d._attributes_dump()
p(d.as_dict())

