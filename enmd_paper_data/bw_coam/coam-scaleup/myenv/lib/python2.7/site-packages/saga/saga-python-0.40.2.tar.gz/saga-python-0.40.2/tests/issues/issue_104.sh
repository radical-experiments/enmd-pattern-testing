#!/bin/bash 

while true; do 
  (true &)&
  echo -n " "
done 

