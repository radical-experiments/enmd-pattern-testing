
__author__    = "Andre Merzky"
__copyright__ = "Copyright 2013, The SAGA Project"
__license__   = "MIT"


# ------------------------------------------------------------------------------
#
class Async :
    """
    tagging interface for SAGA classes which implement asynchronous methods.
    """
    pass
#
# ------------------------------------------------------------------------------

